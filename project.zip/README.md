# Private Vault (Android App)

Aapki apni privacy ke liye ek offline app — login se pehle koi bhi data nahi khul sakta,
aur sara data sirf isi phone ke andar (app ke private storage mein) rehta hai. Koi
internet / cloud use nahi hota.

## Isay APK banane ka tareeqa (bilkul free, offline)

1. **Android Studio** install karein (agar pehle se nahi hai): https://developer.android.com/studio
2. Is poore `PrivateVault` folder ko apne computer par copy karein.
3. Android Studio kholein → **Open** → is `PrivateVault` folder ko select karein.
4. Android Studio khud gradle sync karega (isay pehli baar internet chahiye hoga taake
   libraries download ho sakein — uske baad app offline hi chalta hai).
5. Upar "Run" (▶️) button dabayein, ya **Build > Build Bundle(s)/APK(s) > Build APK(s)**
   se seedha APK file bana lein.
6. Bani hui APK apne phone mein install kar lein (USB se ya file transfer karke).

## Features

- **Login/Signup**: Pehli dafa app khulay to username + password set karte hain
  (encrypted store hota hai, kabhi plain text mein save nahi hota).
- **Documents**: Koi bhi file (PDF, Word, etc.) import karke app ke andar private
  storage mein save karein.
- **Photos/Videos**: Apni personal photos app ke andar copy kar lein.
- **Notes**: Simple private notes likhein.
- Har cheez sirf app ke apne folder (`filesDir/vault`) mein hoti hai — koi doosri
  app ya gallery is data ko nahi dekh sakti, aur kuch bhi internet par nahi jata.

## Aage badhane ke liye ideas (agar chahen)

- App lock ko biometric (fingerprint) se bhi jorha ja sakta hai.
- Files ko AES encrypt bhi kiya ja sakta hai (abhi sirf app-private folder mein
  hidden hain, encrypted nahi).
- Videos import karne ke liye Media tab mein mime filter "video/*" bhi add
  kiya ja sakta hai (abhi "image/*" set hai).

Agar in mein se koi feature add karwana ho to bata dein, main code update kar dunga.
