package com.privatevault.myapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.privatevault.myapp.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var auth: AuthManager
    private var isSignupMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = AuthManager(this)

        isSignupMode = !auth.isAccountCreated()
        if (isSignupMode) {
            binding.tvSubtitle.text = "Pehli baar? Apna username aur password set karein"
            binding.btnAction.text = "Account Banayein"
        } else {
            binding.tvSubtitle.text = "Apna data dekhne ke liye login karein"
            binding.btnAction.text = "Login"
        }

        binding.btnAction.setOnClickListener {
            handleAction()
        }
    }

    private fun handleAction() {
        val username = binding.etUsername.text.toString().trim()
        val password = binding.etPassword.text.toString()

        if (username.isEmpty() || password.isEmpty()) {
            showError("Username aur password dono likhein")
            return
        }
        if (password.length < 4) {
            showError("Password kam se kam 4 characters ka ho")
            return
        }

        if (isSignupMode) {
            auth.createAccount(username, password)
            goToVault()
        } else {
            if (auth.checkLogin(username, password)) {
                goToVault()
            } else {
                showError("Username ya password ghalat hai")
            }
        }
    }

    private fun showError(msg: String) {
        binding.tvError.text = msg
        binding.tvError.visibility = android.view.View.VISIBLE
    }

    private fun goToVault() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
