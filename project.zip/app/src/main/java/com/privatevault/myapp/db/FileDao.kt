package com.privatevault.myapp.db

import androidx.room.*

@Dao
interface FileDao {
    @Query("SELECT * FROM vault_files WHERE category = :category ORDER BY addedAt DESC")
    suspend fun getByCategory(category: String): List<FileEntity>

    @Insert
    suspend fun insert(file: FileEntity): Long

    @Delete
    suspend fun delete(file: FileEntity)
}
