package com.privatevault.myapp

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest

/**
 * Stores the username/password ONLY on this device, encrypted with the
 * Android Keystore (via EncryptedSharedPreferences). Nothing ever leaves
 * the phone. The password itself is additionally hashed before storage,
 * so even the encrypted file never contains the plain password.
 */
class AuthManager(context: Context) {

    private val prefs: SharedPreferences

    init {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        prefs = EncryptedSharedPreferences.create(
            context,
            "vault_auth_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun isAccountCreated(): Boolean = prefs.contains("username")

    fun createAccount(username: String, password: String) {
        prefs.edit()
            .putString("username", username)
            .putString("password_hash", hash(password))
            .apply()
    }

    fun checkLogin(username: String, password: String): Boolean {
        val savedUser = prefs.getString("username", null) ?: return false
        val savedHash = prefs.getString("password_hash", null) ?: return false
        return savedUser == username && savedHash == hash(password)
    }

    private fun hash(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
