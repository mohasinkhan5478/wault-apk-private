package com.privatevault.myapp.fragments

class DocumentsFragment : FileListFragment() {
    override val category = "document"
    override val mimeFilter = "*/*"
}
