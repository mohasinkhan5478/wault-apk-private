package com.privatevault.myapp.fragments

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.privatevault.myapp.adapters.FileAdapter
import com.privatevault.myapp.databinding.FragmentFileListBinding
import com.privatevault.myapp.db.AppDatabase
import com.privatevault.myapp.db.FileEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

/**
 * Shared logic for "Documents" and "Media" tabs.
 * Picking a file COPIES its bytes into the app's private storage
 * (filesDir/vault/...), which other apps cannot access. The original
 * file the user picked is left untouched.
 */
abstract class FileListFragment : Fragment() {

    protected abstract val category: String   // "document" or "media"
    protected abstract val mimeFilter: String  // e.g. "*/*" or "image/*,video/*"

    private var _binding: FragmentFileListBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: FileAdapter
    private val items = mutableListOf<FileEntity>()

    private val pickLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { importFile(it) }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFileListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = FileAdapter(items, onClick = { openFile(it) }, onDelete = { confirmDelete(it) })
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerView.adapter = adapter

        binding.fabAdd.setOnClickListener { pickLauncher.launch(mimeFilter) }

        loadFiles()
    }

    private fun loadFiles() {
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(requireContext()).fileDao()
            val result = withContext(Dispatchers.IO) { dao.getByCategory(category) }
            items.clear()
            items.addAll(result)
            adapter.notifyDataSetChanged()
            binding.tvEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun importFile(uri: Uri) {
        lifecycleScope.launch {
            val context = requireContext()
            val name = queryDisplayName(uri) ?: "file_${System.currentTimeMillis()}"
            val mime = context.contentResolver.getType(uri) ?: "application/octet-stream"

            val vaultDir = File(context.filesDir, "vault").apply { mkdirs() }
            val destFile = File(vaultDir, "${UUID.randomUUID()}_$name")

            val success = withContext(Dispatchers.IO) {
                try {
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        destFile.outputStream().use { output -> input.copyTo(output) }
                    }
                    true
                } catch (e: Exception) {
                    false
                }
            }

            if (success) {
                val entity = FileEntity(
                    displayName = name,
                    localPath = destFile.absolutePath,
                    category = category,
                    mimeType = mime,
                    addedAt = System.currentTimeMillis()
                )
                val dao = AppDatabase.getInstance(context).fileDao()
                withContext(Dispatchers.IO) { dao.insert(entity) }
                loadFiles()
            }
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        val cursor = requireContext().contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            val index = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (it.moveToFirst() && index >= 0) return it.getString(index)
        }
        return null
    }

    private fun openFile(entity: FileEntity) {
        val context = requireContext()
        val file = File(entity.localPath)
        if (!file.exists()) return
        val uri: Uri = androidx.core.content.FileProvider.getUriForFile(
            context, "com.privatevault.myapp.fileprovider", file
        )
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, entity.mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            // No app available to open this file type - safe to ignore for now.
        }
    }

    private fun confirmDelete(entity: FileEntity) {
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(requireContext()).fileDao()
            withContext(Dispatchers.IO) {
                dao.delete(entity)
                File(entity.localPath).delete()
            }
            adapter.removeItem(entity)
            binding.tvEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
