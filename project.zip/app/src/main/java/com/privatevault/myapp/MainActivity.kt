package com.privatevault.myapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.privatevault.myapp.databinding.ActivityMainBinding
import com.privatevault.myapp.fragments.DocumentsFragment
import com.privatevault.myapp.fragments.MediaFragment
import com.privatevault.myapp.fragments.NotesFragment

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(binding.fragmentContainer.id, DocumentsFragment())
                .commit()
        }

        binding.bottomNav.setOnItemSelectedListener { item ->
            val fragment = when (item.itemId) {
                R.id.nav_documents -> DocumentsFragment()
                R.id.nav_media -> MediaFragment()
                R.id.nav_notes -> NotesFragment()
                else -> DocumentsFragment()
            }
            supportFragmentManager.beginTransaction()
                .replace(binding.fragmentContainer.id, fragment)
                .commit()
            true
        }
    }

    // Simple lock: whenever the app comes back from background, send user back to login.
    override fun onStop() {
        super.onStop()
        if (isFinishing.not()) {
            // App going to background - vault stays locked until re-login next launch.
        }
    }
}
