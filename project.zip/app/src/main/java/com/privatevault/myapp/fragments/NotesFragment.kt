package com.privatevault.myapp.fragments

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.privatevault.myapp.adapters.NoteAdapter
import com.privatevault.myapp.databinding.DialogAddNoteBinding
import com.privatevault.myapp.databinding.FragmentNotesBinding
import com.privatevault.myapp.db.AppDatabase
import com.privatevault.myapp.db.NoteEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class NotesFragment : Fragment() {

    private var _binding: FragmentNotesBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: NoteAdapter
    private val items = mutableListOf<NoteEntity>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentNotesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = NoteAdapter(items) { showNoteDialog(it) }
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerView.adapter = adapter

        binding.fabAdd.setOnClickListener { showNoteDialog(null) }

        loadNotes()
    }

    private fun loadNotes() {
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(requireContext()).noteDao()
            val result = withContext(Dispatchers.IO) { dao.getAll() }
            items.clear()
            items.addAll(result)
            adapter.notifyDataSetChanged()
            binding.tvEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun showNoteDialog(existing: NoteEntity?) {
        val dialogBinding = DialogAddNoteBinding.inflate(LayoutInflater.from(requireContext()))
        existing?.let {
            dialogBinding.etNoteTitle.setText(it.title)
            dialogBinding.etNoteBody.setText(it.body)
        }

        AlertDialog.Builder(requireContext())
            .setTitle(if (existing == null) "Naya Note" else "Note")
            .setView(dialogBinding.root)
            .setPositiveButton("Save") { _, _ ->
                val title = dialogBinding.etNoteTitle.text.toString().trim()
                val body = dialogBinding.etNoteBody.text.toString().trim()
                if (title.isNotEmpty() || body.isNotEmpty()) {
                    saveNote(title.ifEmpty { "Untitled" }, body)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun saveNote(title: String, body: String) {
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(requireContext()).noteDao()
            withContext(Dispatchers.IO) {
                dao.insert(NoteEntity(title = title, body = body, updatedAt = System.currentTimeMillis()))
            }
            loadNotes()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
