package com.privatevault.myapp.db

import androidx.room.Entity
import androidx.room.PrimaryKey

// category: "document" or "media"
@Entity(tableName = "vault_files")
data class FileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val displayName: String,
    val localPath: String,
    val category: String,
    val mimeType: String,
    val addedAt: Long
)
