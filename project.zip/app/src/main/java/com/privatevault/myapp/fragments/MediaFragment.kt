package com.privatevault.myapp.fragments

class MediaFragment : FileListFragment() {
    override val category = "media"
    override val mimeFilter = "image/*"
    // Note: GetContent() only accepts one MIME pattern. To also import videos
    // easily, users can just tap the + button again and this can be swapped
    // to "video/*", or upgraded later to a custom picker that allows both.
}
